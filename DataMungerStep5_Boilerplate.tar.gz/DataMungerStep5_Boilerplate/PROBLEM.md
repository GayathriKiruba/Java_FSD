### Problem Statement

In this assignment step 5, we will perform the following task:

    1. Filter the data based on the query with multiple where conditions.
         For Example: where season >= 2013 or toss_decision!=bat and city=Bangalore;
    
    2. Filter the data based on selected fields.
        For Example : select city,winner,team1,team2 from ipl.csv;
    
    3. Store the filtered data in a json file.


