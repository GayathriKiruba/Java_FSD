package com.stackroute.datamunger.query.parser;

import java.util.ArrayList;
import java.util.List;

/* 
 * This class will contain the elements of the parsed Query String such as conditions,
 * logical operators,aggregate functions, file name, fields group by fields, order by
 * fields, Query Type
 * */

public class QueryParameter {
	private String fileName;
	private String baseQuery;
	private List<Restriction> restrictions;
	private List<String> logicalOperators;
	private List<String> fields;
	private List<AggregateFunction> aggregateFunctions;
	private List<String> groupByFields;
	private List<String> orderByFields;

	// Constant variables
	private static final String GROUP= "group";
	private static final String ORDER= "order";
	private static final String GRORBY= "by";
	private static final String WHERE= "where";
	private static final String REGW="[\\W]+";

	// Utility Mathods

	public String[] getSplitStrings(final String queryString) {
		final String queryLowerCase=queryString.toLowerCase();
		return queryLowerCase.split(" ");
	}

	public static boolean empty( final String s ) {
		// Null-safe, short-circuit evaluation.
		return s == null || s.trim().isEmpty();
	}

	public String getCoreQuery(final String queryString) {
		final StringBuffer output = new StringBuffer();
		final String [] query = this.getSplitStrings(queryString);
		for(int i=0;i<query.length;i++) {
			if(query[i].equals(WHERE) || query[i].equals(GROUP) || query[i].equals(ORDER) && query[i+1].equals(GRORBY)){
				break;
			}
			output.append(query[i]);
			output.append(' ');
		}
		return output.toString().trim();
	}

	public String getFileName() {
		return fileName;
	}



	public void setFileName(String queryString) {
		final StringBuffer output = new StringBuffer();
		final String [] query = this.getSplitStrings(queryString);
		for(int i=0;i<query.length;i++) {
			if(query[i].endsWith(".csv")){
				output.append(query[i]);
			}	
		}
		this.fileName = output.toString();
	}

	public String getBaseQuery() {
		return baseQuery;
	}

	public void setBaseQuery(String baseQuery) {
		this.baseQuery = this.getCoreQuery(baseQuery);
	}
	public List<Restriction> getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(String queryString) {
		final String [] query = queryString.split(" ");
		final StringBuffer output = new StringBuffer();
		List<Restriction> liresult=null;
		String result[]=null;
		if(queryString.contains(" where ")) {
			for(int i=0;i<query.length;i++) {
				if(query[i].contains(WHERE)){
					for(int j=i+1;j<query.length;j++) {
						if(query[j].equals(ORDER) || query[j].equals(GROUP) && query[j+1].equals(GRORBY)) {
							break;
						}
						output.append(query[j]);
						output.append(' ');
					}
					break;
				}
			}
			result= output.toString().trim().split(" and | or |;");
			if(result!=null) {
				liresult=new ArrayList<Restriction>();
				for(int i=0;i<result.length;i++) {
					if(result[i].contains(">=")) {
						String[] res = result[i].split(REGW);
						Restriction restriction = new Restriction(res[0].trim(),res[1].trim(),">=");
						liresult.add(restriction);
					}
					else if(result[i].contains("<=")) {
						String[] res = result[i].split(REGW);
						Restriction restriction = new Restriction(res[0].trim(),res[1].trim(),"<=");
						liresult.add(restriction);
					}
					else if(result[i].contains(">")) {
						String[] res = result[i].split(REGW);
						Restriction restriction = new Restriction(res[0].trim(),res[1].trim(),">");
						liresult.add(restriction);
					}
					else if(result[i].contains("<")) {
						String[] res = result[i].split(REGW);
						Restriction restriction = new Restriction(res[0].trim(),res[1].trim(),"<");
						liresult.add(restriction);
					}
					else if(result[i].contains("=")) {
						String[] res = result[i].split(REGW);
						Restriction restriction = new Restriction(res[0].trim(),res[1].trim(),"=");
						liresult.add(restriction);
					}
				}
			}
			}
			this.restrictions = liresult;
		}
		public List<String> getLogicalOperators() {
			return logicalOperators;
		}
		public void setLogicalOperators(String queryString) {
			final String [] query = this.getSplitStrings(queryString);
			final StringBuffer output= new StringBuffer();
			String result[]=null;
			List<String> liresult=null;
			if(queryString.contains(" where ")) {
				for(int i=0;i<query.length;i++) {
					if(query[i].contains(WHERE)){
						for(int j=i+1;j<query.length;j++) {
							if(query[j].equals(ORDER) || query[j].equals(GROUP) && query[j+1].equals(GRORBY)){
								break;
							}
							if(query[j].equals("and") || query[j].equals("or")) {
								output.append(query[j]);
								output.append(' ');
							}
						}
						break;
					}
				}
				liresult=new ArrayList<String>();
				result= output.toString().split(" ");
				for (String string : result) {
					liresult.add(string);
				}
			}
			this.logicalOperators = liresult;
		}
		
		public List<String> getFields() {
			return fields;
		}
		
		public void setFields(String fields) {
			final StringBuffer output = new StringBuffer();
			String result[]=null;
			final String [] query = this.getCoreQuery(fields).split(" ");
			List<String> liresult=new ArrayList<String>();
			for(int i=0;i<query.length;i++) {
				if(query[i].contains("select")){
					continue;
				}
				else if(query[i].contains("from")){
					break;
				}
				output.append(query[i]);
			}
			result=output.toString().trim().split(",");
			for (String string : result) {
				liresult.add(string);
			}
			this.fields = liresult;
		}
		public List<AggregateFunction> getAggregateFunctions() {
			return aggregateFunctions;
		}
		public void setAggregateFunctions(String queryString) {
			final StringBuffer output = new StringBuffer();
			String result[]=null;
			final String [] query = this.getCoreQuery(queryString).split(" ");
			List<AggregateFunction> liresult=new ArrayList<AggregateFunction>();
			for(int i=0;i<query.length;i++) {
				if(query[i].contains("select")){
					continue;
				}
				else if(query[i].contains("from")){
					break;
				}
				output.append(query[i]);
			}
			result=output.toString().trim().split(",");
			
			if(!result[0].equals("*")) {
				for(int i=0;i<result.length;i++) {
					if(result[i].startsWith("max(")  || result[i].startsWith("min(") ||  result[i].startsWith("count(") || result[i].startsWith("avg(") || result[i].startsWith("sum") && result[i].endsWith(")")) {
						String sep[]=result[i].split("[)|(]");
						AggregateFunction aggregateFunction = new AggregateFunction(sep[1],sep[0]);
						liresult.add(aggregateFunction);
					}			
				}
			}
			this.aggregateFunctions = liresult;
		}
		public List<String> getGroupByFields() {
			return groupByFields;
		}
		public void setGroupByFields(String groupByFields) {
			final StringBuffer output = new StringBuffer();
			String result[]=null;
			List<String> liresult=null;
			final String [] query = this.getSplitStrings(groupByFields);
			for(int i=0;i<query.length;i++) {
				if(query[i].equals(GROUP) && query[i+1].equals(GRORBY)) {
					for(int j=i+2;j<query.length;j++) {
						if(query[j].contains(";") || (query[j].contains(ORDER) && query[j+1].contains(GRORBY))) {
							break;
						}
						output.append(query[j]);
						output.append(' ');
					}
					result= output.toString().trim().split(" |,");
					liresult=new ArrayList<String>();
					for (String string : result) {
						liresult.add(string);
					}
				}
			}
			this.groupByFields = liresult;
		}
		public List<String> getOrderByFields() {
			return orderByFields;
		}
		public void setOrderByFields(String orderByFields) {
			final StringBuffer output = new StringBuffer();
			String[] result=null;
			List<String> liresult=new ArrayList<String>();
			final String [] query = this.getSplitStrings(orderByFields);
			for(int i=0;i<query.length;i++) {
				if(query[i].equals(ORDER) && query[i+1].equals(GRORBY)) {
					for(int j=i+2;j<query.length;j++) {
						if(query[j].contains(";")) {
							break;
						}
						output.append(query[j]);
						output.append(' ');
					}
					result= output.toString().trim().split(" |,");
					for (String string : result) {
						liresult.add(string);
					}
				}
			}
			this.orderByFields = liresult;
		}



	}